(function(root){
  'use strict';

  var Modules = root.BlossomModules = root.BlossomModules || {};

  function text(value){
    return String(value == null ? '' : value).trim();
  }

  function quantity(value){
    if(value == null || String(value).trim() === '') return 0;
    var parsed = parseInt(value, 10);
    return isFinite(parsed) && parsed >= 0 ? parsed : 0;
  }

  Modules.softwareValidation = {
    normalizePayload: function(data){
      data = data || {};
      var modelName = text(data.model_name || data.model || data.os_name);
      var vendorName = text(data.manufacturer_name || data.vendor || data.manufacturer);
      var vendorCode = text(data.manufacturer_code || data.vendor_code);
      var softwareType = text(data.os_type || data.hw_type || data.type || data.category);
      var eoslDate = text(data.eosl_date || data.eosl);
      var note = text(data.remark || data.note || data.description);
      var payload = {
        model_name: modelName || undefined,
        os_type: softwareType || undefined,
        release_date: text(data.release_date),
        eosl_date: eoslDate,
        remark: note
      };
      if(data.license_count != null || data.qty != null){
        payload.license_count = quantity(data.license_count != null ? data.license_count : data.qty);
      }
      if(text(data.os_code || data.code)) payload.os_code = text(data.os_code || data.code);
      if(vendorCode) payload.manufacturer_code = vendorCode;
      if(vendorName) payload.manufacturer_name = vendorName;
      return payload;
    },
    validatePayload: function(payload, context){
      payload = payload || {};
      context = context || {};
      var label = context.label || '소프트웨어';
      var errors = [];
      if(!text(payload.model_name)) errors.push(label + ' 모델명을 입력하세요.');
      if(!text(payload.manufacturer_name || payload.manufacturer_code)) errors.push('제조사를 선택하세요.');
      if(!text(payload.os_type)) errors.push('유형을 선택하세요.');
      if(text(payload.model_name).length > 160) errors.push('모델명은 160자 이내로 입력하세요.');
      return errors;
    }
  };

})(window);