(function(root){
  'use strict';

  var Modules = root.BlossomModules = root.BlossomModules || {};

  function text(value){
    return String(value == null ? '' : value).trim();
  }

  function requestJson(url){
    if(root.BlossomAPI && typeof root.BlossomAPI.get === 'function'){
      return root.BlossomAPI.get(url);
    }
    return fetch(url, {
      credentials: 'same-origin',
      headers: { 'Accept': 'application/json', 'X-Requested-With': 'XMLHttpRequest' }
    }).then(function(response){
      return response.json().catch(function(){ return {}; }).then(function(payload){
        if(!response.ok || payload.success === false){
          throw new Error(payload.message || payload.error || '목록을 불러오지 못했습니다.');
        }
        return payload;
      });
    });
  }

  function listItems(payload){
    payload = payload || {};
    var rows = payload.items || payload.rows || payload.data || [];
    return Array.isArray(rows) ? rows : [];
  }

  function manufacturerOptions(rows){
    var seen = {};
    var options = [];
    (rows || []).forEach(function(row){
      var name = text(row.manufacturer_name || row.vendor || row.name);
      if(!name || seen[name]) return;
      seen[name] = true;
      options.push({ value: name, label: name });
    });
    options.sort(function(left, right){ return left.label.localeCompare(right.label, 'ko'); });
    return options;
  }

  Modules.softwareContextDefaults = {
    os: {
      kind: 'os',
      label: '운영체제',
      listTitle: '운영체제 유형',
      apiBase: '/api/sw-os-types',
      detailKey: 'cat_sw_os_detail',
      detailUrl: '/b/cat_sw_os_detail',
      storageKey: 'os_selected_row',
      typeOptions: ['유닉스', '리눅스', '윈도우', '임베디드']
    }
  };

  Modules.useSoftware = function(rawContext){
    rawContext = rawContext || {};
    var base = Modules.softwareContextDefaults[rawContext.kind] || Modules.softwareContextDefaults.os;
    var context = {};
    Object.keys(base).forEach(function(key){ context[key] = base[key]; });
    Object.keys(rawContext).forEach(function(key){
      if(rawContext[key] != null && rawContext[key] !== '') context[key] = rawContext[key];
    });
    return {
      context: context,
      config: Modules.createSoftwareConfig(context),
      schema: Modules.createSoftwareSchema(context),
      api: Modules.createSoftwareApi(context),
      sources: {
        manufacturers: function(){
          return requestJson('/api/vendor-manufacturers?include_deleted=0').then(function(payload){
            return manufacturerOptions(listItems(payload));
          });
        }
      }
    };
  };

})(window);