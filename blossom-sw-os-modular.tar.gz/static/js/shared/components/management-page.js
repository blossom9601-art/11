(function(root){
  'use strict';

  var Shared = root.BlossomShared = root.BlossomShared || {};

  function escapeHtml(value){
    return String(value == null ? '' : value).replace(/[&<>"']/g, function(ch){
      return { '&':'&amp;', '<':'&lt;', '>':'&gt;', '"':'&quot;', "'":'&#39;' }[ch];
    });
  }

  function formatTemplate(template, context){
    return String(template || '').replace(/\{([a-zA-Z0-9_]+)\}/g, function(_, key){
      return context && context[key] != null ? String(context[key]) : '';
    });
  }

  function pageRows(state){
    var start = (state.page - 1) * state.pageSize;
    return state.filtered.slice(start, start + state.pageSize);
  }

  function filterRows(rows, columns, search){
    var q = String(search || '').trim().toLowerCase();
    if(!q) return rows.slice();
    return rows.filter(function(row){
      return columns.some(function(column){
        if(column.searchable === false) return false;
        return String(row[column.key] || '').toLowerCase().indexOf(q) >= 0;
      });
    });
  }

  function makeCsv(rows, columns){
    var lines = [columns.map(function(col){ return col.label || col.key; })];
    rows.forEach(function(row){
      lines.push(columns.map(function(col){ return row[col.key] == null ? '' : row[col.key]; }));
    });
    return lines.map(function(line){
      return line.map(function(cell){ return '"' + String(cell).replace(/"/g, '""') + '"'; }).join(',');
    }).join('\r\n');
  }

  function downloadCsv(filename, rows, columns){
    var blob = new Blob(['\ufeff' + makeCsv(rows, columns)], { type: 'text/csv;charset=utf-8;' });
    var link = document.createElement('a');
    link.href = URL.createObjectURL(blob);
    link.download = filename;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    setTimeout(function(){ URL.revokeObjectURL(link.href); }, 1000);
  }

  function mount(options){
    options = options || {};
    var rootEl = options.root;
    var config = options.config || {};
    var context = options.context || {};
    var api = options.api;
    var schema = options.schema || [];
    var sources = {};
    var state = {
      rows: [],
      filtered: [],
      page: 1,
      pageSize: config.pageSize || 10,
      search: '',
      editRow: null
    };
    var table;
    var formBuilder;

    if(config.actions && config.actions.analytics){
      root.__analyticsGetData = function(){
        if(typeof config.getAnalyticsData === 'function') return config.getAnalyticsData(state);
        return state.filtered.length ? state.filtered : state.rows;
      };
    }

    if(!rootEl || !api) return null;

    function renderShell(){
      rootEl.classList.add('bls-management-page');
      if(config.pageClass) rootEl.classList.add(config.pageClass);
      rootEl.innerHTML = '' +
        (config.showHeader === false ? '' : '<div class="page-header">' +
          '<h1>' + escapeHtml(formatTemplate(config.title, context)) + '</h1>' +
          '<p>' + escapeHtml(formatTemplate(config.description, context)) + '</p>' +
        '</div>') +
        '<div class="tab-header bls-management-toolbar">' +
          '<div class="tab-header-left"><h2>' + escapeHtml(context.label || config.listTitle || config.title || '') + ' <span class="count-badge" data-role="count">0</span></h2></div>' +
          '<div class="tab-header-right">' +
            '<div class="search-container" role="search"><div class="search-input-wrapper">' +
              '<img src="/static/image/svg/list/free-icon-search.svg" alt="검색" class="search-icon">' +
              '<input type="text" class="search-input" data-role="search" placeholder="검색" autocomplete="off">' +
              '<button type="button" class="search-clear-btn" data-role="search-clear" title="지우기" aria-label="검색어 지우기"><img src="/static/image/svg/list/free-icon-trash.svg" alt="" class="search-clear-icon" aria-hidden="true"></button>' +
            '</div></div>' +
            '<select class="page-size-select" data-role="page-size" aria-label="페이지 당 행 수"><option value="10">10 개</option><option value="20">20 개</option><option value="50">50 개</option><option value="100">100 개</option></select>' +
            actionButton('delete', '삭제처리', '/static/image/svg/list/free-icon-trash.svg', config.actions && config.actions.delete) +
            actionButton('bulk', '일괄변경', '/static/image/svg/list/free-icon-bulk-edit.svg', config.actions && config.actions.bulk) +
            actionButton('stats', '통계', '/static/image/svg/list/free-icon-chart.svg', config.actions && config.actions.statistics) +
            actionButton('analytics', '통계 분석', '/static/image/svg/free-icon-font-analytics-magnifying-glass.svg', config.actions ? config.actions.analytics : false) +
            actionButton('export', 'CSV 다운로드', '/static/image/svg/list/free-icon-download.svg', config.actions && config.actions.export) +
            actionButton('add', '추가', '/static/image/svg/list/free-icon-plus.svg', config.actions && config.actions.create) +
          '</div>' +
        '</div>' +
        '<div data-role="table"></div>' +
        '<div class="modern-pagination bls-management-pagination">' +
          '<div class="pagination-info"><span data-role="pagination-info">0개 항목</span></div>' +
          '<div class="pagination-controls"><button class="pagination-btn" data-page="first">처음</button><button class="pagination-btn" data-page="prev">이전</button><div class="page-numbers" data-role="page-numbers"></div><button class="pagination-btn" data-page="next">다음</button><button class="pagination-btn" data-page="last">마지막</button></div>' +
        '</div>' +
        modalMarkup('add', '등록') + modalMarkup('edit', '수정');
    }

    function actionButton(action, title, icon, enabled){
      if(enabled === false) return '';
      var idAttr = action === 'analytics' ? ' id="' + escapeHtml(config.analyticsButtonId || 'system-analytics-btn') + '"' : '';
      return '<button type="button" class="header-btn" data-action="' + action + '"' + idAttr + ' title="' + escapeHtml(title) + '" aria-label="' + escapeHtml(title) + '"><img src="' + escapeHtml(icon) + '" alt="' + escapeHtml(title) + '" class="header-icon"></button>';
    }

    function modalMarkup(kind, label){
      return '<div class="server-add-modal modal-overlay-full" data-modal="' + kind + '" aria-hidden="true">' +
        '<div class="server-add-content">' +
          '<div class="server-add-header"><div class="server-add-title"><h3>' + escapeHtml((context.label || config.title || '') + ' ' + label) + '</h3></div><button type="button" class="close-btn" data-modal-close title="닫기" aria-label="닫기">×</button></div>' +
          '<div class="server-add-body"><form data-role="' + kind + '-form"></form></div>' +
          '<div class="server-add-actions align-right"><div class="action-buttons right"><button type="button" class="btn-primary" data-action="' + kind + '-save">저장</button></div></div>' +
        '</div>' +
      '</div>';
    }

    function setCount(){
      var count = rootEl.querySelector('[data-role="count"]');
      if(count) count.textContent = String(state.filtered.length);
    }

    function renderPagination(){
      var total = state.filtered.length;
      var pages = Math.max(1, Math.ceil(total / state.pageSize));
      if(state.page > pages) state.page = pages;
      var start = total ? ((state.page - 1) * state.pageSize + 1) : 0;
      var end = total ? Math.min(total, state.page * state.pageSize) : 0;
      var info = rootEl.querySelector('[data-role="pagination-info"]');
      if(info) info.textContent = total ? (start + '-' + end + ' / ' + total + '개 항목') : '0개 항목';
      var numbers = rootEl.querySelector('[data-role="page-numbers"]');
      if(numbers){
        var html = '';
        for(var page = 1; page <= pages; page += 1){
          html += '<button type="button" class="page-btn' + (page === state.page ? ' active' : '') + '" data-page-number="' + page + '">' + page + '</button>';
        }
        numbers.innerHTML = html;
      }
    }

    function render(){
      state.filtered = filterRows(state.rows, config.columns || [], state.search);
      setCount();
      renderPagination();
      var rows = pageRows(state);
      table.setRows(rows);
      if(typeof config.afterRender === 'function'){
        config.afterRender(rows, state, { root: rootEl, table: table, render: render, showMessage: showMessage });
      }
    }

    function load(){
      return api.list().then(function(result){
        state.rows = result.rows || [];
        if(typeof config.normalizeRows === 'function') state.rows = config.normalizeRows(state.rows);
        render();
      }).catch(function(err){ showMessage(err.message || '목록을 불러오지 못했습니다.'); });
    }

    function showMessage(message){
      if(root.showToast) root.showToast(message, 'error');
      else if(document.getElementById('system-message-modal')){
        var title = document.getElementById('message-title');
        var content = document.getElementById('message-content');
        if(title) title.textContent = '알림';
        if(content) content.textContent = message || '';
        if(root.BlossomModal) root.BlossomModal.open('system-message-modal');
        else document.getElementById('system-message-modal').classList.add('show');
      }
      else alert(message);
    }

    function openModal(kind, row){
      state.editRow = row || null;
      var modal = rootEl.querySelector('[data-modal="' + kind + '"]');
      var form = rootEl.querySelector('[data-role="' + kind + '-form"]');
      if(form) form.innerHTML = formBuilder.render(row || {});
      if(root.BlossomSearchableSelect && typeof root.BlossomSearchableSelect.syncAll === 'function'){
        root.BlossomSearchableSelect.syncAll(modal || rootEl);
      }
      if(root.BlossomModal) root.BlossomModal.open(modal);
      else modal.classList.add('show');
    }

    function closeModal(kind){
      var modal = rootEl.querySelector('[data-modal="' + kind + '"]');
      if(root.BlossomModal) root.BlossomModal.close(modal);
      else modal.classList.remove('show');
    }

    function save(kind){
      var form = rootEl.querySelector('[data-role="' + kind + '-form"]');
      var data = formBuilder.collect(form);
      var errors = formBuilder.validate(data);
      if(errors.length){ showMessage(errors[0]); return; }
      var meta = { kind: kind, row: state.editRow, state: state, showMessage: showMessage };
      var prepared = typeof config.beforeSave === 'function' ? Promise.resolve(config.beforeSave(data, meta)) : Promise.resolve(data);
      prepared.then(function(nextData){
        var promise = kind === 'edit' && state.editRow ? api.update(state.editRow[config.rowKey || 'id'], nextData || data) : api.create(nextData || data);
        return promise.then(function(){ closeModal(kind); return load(); });
      }).catch(function(err){ showMessage(err.message || '저장하지 못했습니다.'); });
    }

    function bind(){
      rootEl.addEventListener('input', function(event){
        if(event.target.getAttribute('data-role') === 'search'){
          state.search = event.target.value || '';
          state.page = 1;
          render();
        }
      });
      rootEl.addEventListener('change', function(event){
        if(event.target.getAttribute('data-role') === 'page-size'){
          state.pageSize = Number(event.target.value || 10);
          state.page = 1;
          render();
        }
      });
      rootEl.addEventListener('click', function(event){
        var action = event.target.closest('[data-action]');
        if(action){
          var name = action.getAttribute('data-action');
          if(name === 'add') openModal('add');
          if(name === 'add-save') save('add');
          if(name === 'edit-save') save('edit');
          if(name === 'export') downloadCsv((config.exportName || config.id || 'data') + '.csv', state.filtered, config.columns || []);
          if(name === 'delete') deleteSelected();
          if(name === 'bulk') bulkEdit();
          if(name === 'stats' && typeof config.openStats === 'function') config.openStats(state.filtered, context);
          return;
        }
        var clear = event.target.closest('[data-role="search-clear"]');
        if(clear){
          var search = rootEl.querySelector('[data-role="search"]');
          if(search) search.value = '';
          state.search = '';
          state.page = 1;
          render();
          if(search) search.focus();
          return;
        }
        var pageNumber = event.target.closest('[data-page-number]');
        if(pageNumber){ state.page = Number(pageNumber.getAttribute('data-page-number') || 1); render(); return; }
        var pageBtn = event.target.closest('[data-page]');
        if(pageBtn){ movePage(pageBtn.getAttribute('data-page')); }
      });
    }

    function movePage(kind){
      var pages = Math.max(1, Math.ceil(state.filtered.length / state.pageSize));
      if(kind === 'first') state.page = 1;
      if(kind === 'prev') state.page = Math.max(1, state.page - 1);
      if(kind === 'next') state.page = Math.min(pages, state.page + 1);
      if(kind === 'last') state.page = pages;
      render();
    }

    function deleteSelected(){
      var ids = table.getSelectedIds();
      if(!ids.length){ showMessage('삭제처리할 행을 먼저 선택하세요.'); return; }
      var confirmPromise = root.BlossomModal ? root.BlossomModal.confirm('선택된 ' + ids.length + '개 항목을 삭제처리하시겠습니까?', { title: '삭제처리' }) : Promise.resolve(confirm('선택된 항목을 삭제처리하시겠습니까?'));
      confirmPromise.then(function(ok){
        if(!ok) return;
        return api.bulkDelete(ids).then(function(){ table.clearSelection(); return load(); });
      }).catch(function(err){ showMessage(err.message || '삭제처리하지 못했습니다.'); });
    }

    function bulkEdit(){
      var ids = table.getSelectedIds();
      if(!ids.length){ showMessage('일괄변경할 행을 먼저 선택하세요.'); return; }
      if(typeof config.onBulk === 'function'){
        config.onBulk(ids, state.filtered, { openEdit: openModal, showMessage: showMessage });
        return;
      }
      if(ids.length === 1){
        var row = null;
        for(var i = 0; i < state.rows.length; i += 1){
          if(String(state.rows[i][config.rowKey || 'id']) === String(ids[0])){ row = state.rows[i]; break; }
        }
        if(row) openModal('edit', row);
        return;
      }
      showMessage('여러 행 일괄변경은 메뉴별 설정에서 확장할 수 있습니다.');
    }

    function loadSources(){
      var sourceFns = options.sources || {};
      var names = Object.keys(sourceFns);
      if(!names.length) return Promise.resolve();
      return Promise.all(names.map(function(name){
        return sourceFns[name]().then(function(items){ sources[name] = items || []; }).catch(function(){ sources[name] = []; });
      }));
    }

    renderShell();
    formBuilder = Shared.createFormBuilder({ schema: schema, sources: sources });
    table = Shared.createDataTable({
      root: rootEl.querySelector('[data-role="table"]'),
      columns: config.columns || [],
      rowKey: config.rowKey || 'id',
      actions: config.actions,
      events: { edit: function(row){ openModal('edit', row); } }
    });
    bind();

    return loadSources().then(function(){ formBuilder.setSources(sources); return load(); });
  }

  Shared.ManagementPage = { mount: mount };

})(window);
