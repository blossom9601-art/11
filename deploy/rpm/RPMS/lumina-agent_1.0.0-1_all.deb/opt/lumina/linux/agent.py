#!/usr/bin/env python3
"""Lumina 자산 자동 탐색 에이전트 — Linux 데몬

사용법:
    python3 agent.py              # 데몬 모드 (interval 주기로 반복)
    python3 agent.py --once       # 1회 수집 후 종료
    python3 agent.py --conf /etc/lumina/lumina.conf
"""

import argparse
import json
import logging
import os
import signal
import sys
import time
import urllib.request
import urllib.error

# 에이전트 루트를 sys.path에 추가
_AGENT_ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
if _AGENT_ROOT not in sys.path:
    sys.path.insert(0, _AGENT_ROOT)

from common.config import AgentConfig
from common.collector import build_payload, save_payload
from linux.collectors.interface import InterfaceCollector
from linux.collectors.account import AccountCollector
from linux.collectors.package import PackageCollector

logger = logging.getLogger("lumina")

_running = True


def _setup_logging():
    handler = logging.StreamHandler(sys.stdout)
    handler.setFormatter(logging.Formatter(
        "%(asctime)s [%(levelname)s] %(message)s", datefmt="%Y-%m-%d %H:%M:%S"
    ))
    logger.setLevel(logging.INFO)
    logger.addHandler(handler)

    # 파일 로그
    log_dir = "/var/log/lumina"
    os.makedirs(log_dir, exist_ok=True)
    fh = logging.FileHandler(os.path.join(log_dir, "lumina.log"), encoding="utf-8")
    fh.setFormatter(logging.Formatter(
        "%(asctime)s [%(levelname)s] %(message)s", datefmt="%Y-%m-%d %H:%M:%S"
    ))
    logger.addHandler(fh)


def _signal_handler(signum, frame):
    global _running
    logger.info("Shutdown signal received (signal=%d), stopping agent.", signum)
    _running = False


def _push_to_server(config: AgentConfig, payload: dict) -> bool:
    """수집 결과를 서버로 전송. 성공 시 True, 실패 시 False (로컬 저장 fallback)."""
    if not config.server_url:
        return False
    try:
        import ssl
        data = json.dumps(payload, ensure_ascii=False).encode("utf-8")
        req = urllib.request.Request(
            config.server_url,
            data=data,
            headers={"Content-Type": "application/json"},
            method="POST",
        )
        ctx = ssl.create_default_context()
        if not config.verify_ssl:
            ctx.check_hostname = False
            ctx.verify_mode = ssl.CERT_NONE
        with urllib.request.urlopen(req, timeout=30, context=ctx) as resp:
            logger.info("Data sent to server (status=%d)", resp.status)
            return True
    except (urllib.error.URLError, OSError) as e:
        logger.warning("Server unreachable, saving locally (error=%s)", e)
        return False


def run_once(config: AgentConfig):
    """수집 1회 실행"""
    collectors = []
    if "interface" in config.collectors:
        collectors.append(InterfaceCollector())
    if "account" in config.collectors:
        collectors.append(AccountCollector())
    if "package" in config.collectors:
        collectors.append(PackageCollector())

    logger.info("Collection started (hostname=%s, collectors=%s)", config.hostname, [c.name for c in collectors])
    payload = build_payload(collectors)

    # 서버 전송 시도 → 실패 시 로컬 JSON 저장
    if not _push_to_server(config, payload):
        out_path = config.output_path()
        save_payload(payload, out_path)
        logger.info("Collection complete -> %s", out_path)
    else:
        logger.info("Collection complete -> sent to server")


def _send_heartbeat(config: AgentConfig):
    """서버에 heartbeat 전송"""
    if not config.server_host:
        return
    import ssl as _ssl
    import socket as _sock
    try:
        url = f"{config.server_protocol}://{config.server_host}:{config.server_port}/api/agent/heartbeat"
        body = json.dumps({"hostname": config.hostname or _sock.gethostname()}).encode("utf-8")
        ctx = _ssl.create_default_context()
        if not config.verify_ssl:
            ctx.check_hostname = False
            ctx.verify_mode = _ssl.CERT_NONE
        req = urllib.request.Request(
            url, data=body,
            headers={"Content-Type": "application/json"},
            method="POST",
        )
        with urllib.request.urlopen(req, timeout=5, context=ctx):
            pass
    except Exception:
        pass


def _interactive_setup(config):
    """대화형으로 서버 연결 정보를 입력받아 설정 파일에 저장"""
    print("\n===== Lumina 서버 연결 설정 =====")
    print("에이전트가 데이터를 전송할 서버 정보를 입력하세요.\n")
    if config.server_host:
        print("  현재 설정: %s\n" % config.server_url)
    proto = input("  프로토콜 [%s]: " % config.server_protocol).strip() or config.server_protocol
    host = input("  서버 IP [%s]: " % (config.server_host or "")).strip() or config.server_host
    port = input("  포트 [%s]: " % config.server_port).strip() or str(config.server_port)
    verify = input("  SSL 인증서 검증 (y/N) [%s]: " % ("y" if config.verify_ssl else "N")).strip().lower()
    if not host:
        print("서버 IP가 입력되지 않아 종료합니다.")
        sys.exit(0)
    config.server_protocol = proto
    config.server_host = host
    try:
        config.server_port = int(port)
    except ValueError:
        config.server_port = 8080
    config.verify_ssl = verify in ("y", "yes")
    config.save()
    print("\n설정 저장 완료: %s" % config.server_url)
    print("서비스 시작: systemctl start lumina-agent\n")


def main():
    parser = argparse.ArgumentParser(description="Lumina 자산 자동 탐색 에이전트 (Linux)")
    parser.add_argument("--once", action="store_true", help="1회 수집 후 종료")
    parser.add_argument("--setup", action="store_true", help="서버 연결 설정 후 종료")
    parser.add_argument("--conf", default=None, help="설정 파일 경로")
    args = parser.parse_args()

    _setup_logging()

    config = AgentConfig(conf_path=args.conf)

    # --setup 모드: 대화형 설정 후 종료
    if args.setup:
        _interactive_setup(config)
        return

    # server_host가 미설정이면 CLI로 입력받기
    if not config.server_url:
        if not sys.stdin.isatty():
            logger.error("Server connection not configured. "
                         "Run 'lumina-agent --setup' in a terminal "
                         "to complete initial setup.")
            sys.exit(1)
        _interactive_setup(config)

    logger.info("Agent started (interval=%ds, output=%s, server=%s)",
                config.interval, config.output_dir,
                "configured" if config.server_url else "(none)")

    signal.signal(signal.SIGTERM, _signal_handler)
    signal.signal(signal.SIGINT, _signal_handler)

    if args.once:
        run_once(config)
        return

    # 데몬 루프
    while _running:
        try:
            run_once(config)
            _send_heartbeat(config)
        except Exception:
            logger.exception("Unexpected error during collection cycle")

        # interval 동안 60초 간격으로 heartbeat 전송
        elapsed = 0
        hb_interval = min(60, config.interval)
        while _running and elapsed < config.interval:
            time.sleep(hb_interval)
            elapsed += hb_interval
            if _running and elapsed < config.interval:
                try:
                    _send_heartbeat(config)
                except Exception:
                    pass

    logger.info("Agent stopped")


if __name__ == "__main__":
    main()
