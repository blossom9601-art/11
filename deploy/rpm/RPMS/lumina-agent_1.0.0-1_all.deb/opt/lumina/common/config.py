"""Lumina 자산 자동 탐색 에이전트 — 공통 설정 모듈"""

import configparser
import os
import platform
import socket

DEFAULT_INTERVAL = 3600  # 1시간
DEFAULT_COLLECTORS = ["interface", "account", "package"]
DEFAULT_PORT = 8080
DEFAULT_PROTOCOL = "https"
API_PATH = "/api/agent/upload"

_CONF_TEMPLATE = """\
# ============================================================================
#  Lumina Agent Configuration
#  Blossom IT Asset Management
#
#  After editing this file, restart the service to apply changes:
#    systemctl restart lumina-agent
#
#  Or run the interactive setup wizard:
#    lumina-agent --setup
# ============================================================================

[server]

# Blossom server hostname or IP address.
# The agent sends collected data to this address.
# Examples:
#   host = 192.168.1.100
#   host = blossom.example.com
host = {host}

# Server port number.
# Default: 8080
# Examples:
#   port = 8080
#   port = 443
port = {port}

# Communication protocol.
# Allowed values: https, http
# Use "https" in production environments.
# Default: https
protocol = {protocol}

# Verify the server's TLS/SSL certificate.
# Set to "true" in production to prevent man-in-the-middle attacks.
# Set to "false" for self-signed certificates or development.
# Default: false
verify_ssl = {verify_ssl}

# (Optional) Path to a CA certificate bundle for server verification.
# Leave empty to use the system default CA store.
# Example:
#   ca_cert = /etc/pki/tls/certs/blossom-ca.pem
ca_cert = {ca_cert}

# (Optional) Client certificate for mutual TLS (mTLS) authentication.
# Both client_cert and client_key must be set to enable mTLS.
# Example:
#   client_cert = /etc/lumina/certs/agent.crt
client_cert = {client_cert}

# (Optional) Private key corresponding to client_cert.
# Example:
#   client_key = /etc/lumina/certs/agent.key
client_key = {client_key}


[agent]

# Data collection interval in seconds.
# The agent collects and sends data at this interval.
# Default: 3600 (1 hour)
# Examples:
#   interval = 1800    # every 30 minutes
#   interval = 3600    # every 1 hour
#   interval = 86400   # once a day
interval = {interval}

# Directory for storing collected JSON data.
# Used as a fallback when the server is unreachable.
# Default: /var/lib/lumina
output_dir = {output_dir}

# Comma-separated list of enabled collectors.
# Available collectors:
#   interface  - Network interfaces, IP addresses, MAC, FC HBA
#   account    - Local user and group accounts
#   package    - Installed packages (rpm, dpkg, snap, pip)
# Default: interface, account, package
collectors = {collectors}

# Automatically start the collection loop on service startup.
# Set to "false" to keep the agent idle until manually triggered.
# Default: false
auto_start = {auto_start}
"""


def _default_output_dir():
    if platform.system() == "Windows":
        return os.path.join(os.environ.get("ProgramData", "C:\\ProgramData"), "Lumina")
    return "/var/lib/lumina"


def _default_conf_path():
    if platform.system() == "Windows":
        return os.path.join(os.environ.get("ProgramData", "C:\\ProgramData"), "Lumina", "lumina.conf")
    return "/etc/lumina/lumina.conf"


class AgentConfig:
    """에이전트 설정 관리"""

    def __init__(self, conf_path=None):
        self.conf_path = conf_path or _default_conf_path()
        self._cp = configparser.ConfigParser()

        # 기본값
        self.interval = DEFAULT_INTERVAL
        self.output_dir = _default_output_dir()
        self.collectors = list(DEFAULT_COLLECTORS)
        self.hostname = socket.gethostname()

        # 서버 연결 (분리 필드)
        self.server_host = ""
        self.server_port = DEFAULT_PORT
        self.server_protocol = DEFAULT_PROTOCOL
        self.verify_ssl = False

        # TLS / mTLS 인증서 경로
        self.ca_cert = ""       # CA 인증서 (서버 검증용)
        self.client_cert = ""   # 클라이언트 인증서 (mTLS)
        self.client_key = ""    # 클라이언트 개인키 (mTLS)

        # 자동 시작
        self.auto_start = False

        self._load()

    @property
    def server_url(self) -> str:
        """server_host/port/protocol로부터 전체 URL 조립"""
        if not self.server_host:
            return ""
        return f"{self.server_protocol}://{self.server_host}:{self.server_port}{API_PATH}"

    @server_url.setter
    def server_url(self, url: str):
        """하위 호환 — 전체 URL을 받아 분리 필드에 파싱"""
        if not url:
            self.server_host = ""
            return
        url = url.strip()
        if "://" in url:
            proto, rest = url.split("://", 1)
            self.server_protocol = proto
        else:
            rest = url
        # 경로 제거
        rest = rest.split("/")[0]
        if ":" in rest:
            host, port_s = rest.rsplit(":", 1)
            self.server_host = host
            try:
                self.server_port = int(port_s)
            except ValueError:
                self.server_port = DEFAULT_PORT
        else:
            self.server_host = rest

    def _load(self):
        if os.path.isfile(self.conf_path):
            self._cp.read(self.conf_path, encoding="utf-8")

            # [server] 섹션 (신규 포맷)
            if self._cp.has_section("server"):
                self.server_host = self._cp.get("server", "host", fallback="").strip()
                self.server_port = self._cp.getint("server", "port", fallback=DEFAULT_PORT)
                self.server_protocol = self._cp.get("server", "protocol", fallback=DEFAULT_PROTOCOL).strip()
                self.verify_ssl = self._cp.getboolean("server", "verify_ssl", fallback=False)
                self.ca_cert = self._cp.get("server", "ca_cert", fallback="").strip()
                self.client_cert = self._cp.get("server", "client_cert", fallback="").strip()
                self.client_key = self._cp.get("server", "client_key", fallback="").strip()

            # [agent] 섹션
            if self._cp.has_section("agent"):
                self.interval = self._cp.getint("agent", "interval", fallback=DEFAULT_INTERVAL)
                self.output_dir = self._cp.get("agent", "output_dir", fallback=self.output_dir)
                raw = self._cp.get("agent", "collectors", fallback="")
                if raw.strip():
                    self.collectors = [c.strip() for c in raw.split(",") if c.strip()]
                self.auto_start = self._cp.getboolean("agent", "auto_start", fallback=False)
                # 하위 호환: 기존 server_url 필드
                if not self.server_host:
                    legacy = self._cp.get("agent", "server_url", fallback="").strip()
                    if legacy:
                        self.server_url = legacy  # setter로 파싱

        os.makedirs(self.output_dir, exist_ok=True)

    def save(self):
        """현재 설정을 conf 파일에 저장"""
        os.makedirs(os.path.dirname(self.conf_path), exist_ok=True)
        with open(self.conf_path, "w", encoding="utf-8") as f:
            f.write(_CONF_TEMPLATE.format(
                host=self.server_host,
                port=self.server_port,
                protocol=self.server_protocol,
                verify_ssl=str(self.verify_ssl).lower(),
                ca_cert=self.ca_cert,
                client_cert=self.client_cert,
                client_key=self.client_key,
                interval=self.interval,
                output_dir=self.output_dir,
                collectors=", ".join(self.collectors),
                auto_start=str(self.auto_start).lower(),
            ))

    def output_path(self):
        """JSON 출력 파일 경로"""
        return os.path.join(self.output_dir, f"{self.hostname}.json")
